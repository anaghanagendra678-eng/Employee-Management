from django.contrib import admin
from .models import Attendance, Task, Salary, PerformanceReview

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ("user", "login_time", "logout_time")
    list_filter = ("user", "login_time")

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ("title", "assigned_to", "assigned_by", "due_date", "status", "progress")
    list_filter = ("status", "due_date")
    search_fields = ("title", "assigned_to__username")

@admin.register(Salary)
class SalaryAdmin(admin.ModelAdmin):
    list_display = ("user", "month", "net_salary", "date_generated")
    list_filter = ("month", "user")

@admin.register(PerformanceReview)
class PerformanceReviewAdmin(admin.ModelAdmin):
    list_display = ("user", "review_date", "kpi_score", "remarks")
    list_filter = ("review_date", "kpi_score")