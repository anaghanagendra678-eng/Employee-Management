from django import forms
from .models import Task, PerformanceReview

# ✅ Task Form (for Admins to assign tasks)
class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ["title", "description", "assigned_to", "due_date", "status", "progress"]
        widgets = {
            "due_date": forms.DateInput(attrs={"type": "date"}),
            "progress": forms.NumberInput(attrs={"min": 0, "max": 100}),
        }


# ✅ Performance Review Form (for Admins to review employees)
class PerformanceReviewForm(forms.ModelForm):
    class Meta:
        model = PerformanceReview
        fields = ["user", "kpi_score", "remarks"]
        widgets = {
            "kpi_score": forms.NumberInput(attrs={"min": 0, "max": 100}),
        }