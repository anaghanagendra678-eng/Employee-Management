from django.urls import path
from django.shortcuts import redirect
from . import views

def redirect_root(request):
    # If user is logged in, send them to the right dashboard
    if request.user.is_authenticated:
        if request.user.is_superuser or request.user.groups.filter(name="Admin").exists():
            return redirect("admin_dashboard")
        else:
            return redirect("employee_dashboard")
    # Otherwise, send to login
    return redirect("login")

urlpatterns = [
    path("", redirect_root, name="root"),   # 👈 root URL
    path("admin-dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path("employee-dashboard/", views.employee_dashboard, name="employee_dashboard"),
    path("assign-task/", views.assign_task, name="assign_task"),
    path("add-review/", views.add_review, name="add_review"),
    path("tasks/", views.view_tasks, name="view_tasks"),
    path("attendance/", views.view_attendance, name="view_attendance"),
    path("salary/", views.view_salary, name="view_salary"),
    path("progress/", views.view_progress, name="view_progress"),
    path("logout/", views.logout_view, name="logout"),
    path("login/", views.login_view, name="login"),
    path("signup/", views.signup_view, name="signup"),
    path("assigned-tasks/", views.assigned_tasks, name="assigned_tasks"),
]