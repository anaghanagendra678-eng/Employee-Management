from django.shortcuts import redirect
from django.contrib import messages

def admin_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated and (
            request.user.is_superuser or request.user.groups.filter(name="Admin").exists()
        ):
            return view_func(request, *args, **kwargs)
        messages.error(request, "You do not have permission to access the Admin dashboard.")
        return redirect("login")
    return wrapper

def employee_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated and request.user.groups.filter(name="Employee").exists():
            return view_func(request, *args, **kwargs)
        messages.error(request, "You do not have permission to access the Employee dashboard.")
        return redirect("login")
    return wrapper