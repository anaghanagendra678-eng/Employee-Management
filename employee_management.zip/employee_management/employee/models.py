from django.db import models
from django.contrib.auth.models import User

# ✅ Attendance model
class Attendance(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    login_time = models.DateTimeField(null=True, blank=True)
    logout_time = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.login_time} to {self.logout_time}"


# ✅ Task model
class Task(models.Model):
    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("In Progress", "In Progress"),
        ("Completed", "Completed"),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    assigned_to = models.ForeignKey(User, on_delete=models.CASCADE, related_name="tasks")
    assigned_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="assigned_tasks")
    due_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="Pending")
    progress = models.IntegerField(default=0)  # percentage (0–100)

    def __str__(self):
        return f"{self.title} - {self.assigned_to.username}"


# ✅ Salary model
class Salary(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    month = models.CharField(max_length=20)  # e.g., "February 2026"
    net_salary = models.DecimalField(max_digits=10, decimal_places=2)
    date_generated = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.month}"


# ✅ Performance Review model
class PerformanceReview(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    review_date = models.DateField(auto_now_add=True)
    kpi_score = models.IntegerField()  # percentage
    remarks = models.TextField(blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.kpi_score}%"
    
