from django.shortcuts import redirect
from django.urls import reverse

class RoleRedirectMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        # Redirect authenticated users to their dashboard if they hit the root URL
        if request.user.is_authenticated and request.path == "/":
            if request.user.is_superuser or request.user.groups.filter(name="Admin").exists():
                return redirect(reverse("admin_dashboard"))
            elif request.user.groups.filter(name="Employee").exists():
                return redirect(reverse("employee_dashboard"))

        return response