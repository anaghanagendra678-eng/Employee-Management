from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User, Group
from django.contrib.auth.decorators import login_required
from django.utils import timezone

from .decorators import admin_required, employee_required
from .models import Attendance, Task, Salary
from .forms import TaskForm, PerformanceReviewForm


# ✅ Login view
def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        group = request.POST.get("group")

        user = authenticate(request, username=username, password=password)
        if user is not None:
            # ✅ Allow superuser to act as Admin
            if user.is_superuser or user.groups.filter(name=group).exists():
                login(request, user)

                # Record login time for employees
                if group == "Employee":
                    Attendance.objects.create(user=user, login_time=timezone.now())

                # Redirect to correct dashboard
                if group == "Admin" or user.is_superuser:
                    return redirect("admin_dashboard")
                else:
                    return redirect("employee_dashboard")
            else:
                messages.error(request, "You are not assigned to the selected group.")
        else:
            messages.error(request, "Invalid username or password.")
    return render(request, "employee/login.html")

# ✅ Signup view
def signup_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        group_name = request.POST.get("group")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect("signup")

        user = User.objects.create_user(username=username, email=email, password=password)

        # Assign user to selected group
        try:
            group = Group.objects.get(name=group_name)
        except Group.DoesNotExist:
            group = Group.objects.create(name=group_name)
        user.groups.add(group)

        login(request, user)
        if group_name == "Admin":
            return redirect("admin_dashboard")
        else:
            return redirect("employee_dashboard")

    return render(request, "employee/signup.html")


# ✅ Admin dashboard
@login_required
@admin_required
def admin_dashboard(request):
    return render(request, "employee/admin_dashboard.html")


# ✅ Employee dashboard
@login_required
@employee_required
def employee_dashboard(request):
    attendance_records = Attendance.objects.filter(user=request.user).order_by('-login_time')
    return render(request, "employee/employee_dashboard.html", {"attendance_records": attendance_records})


# ✅ Logout view
def logout_view(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name="Employee").exists():
            # Update latest attendance record with logout time
            attendance = Attendance.objects.filter(user=request.user).order_by('-login_time').first()
            if attendance and not attendance.logout_time:
                attendance.logout_time = timezone.now()
                attendance.save()

        logout(request)
    return redirect("login")


# ✅ Assign task (Admin only)
@login_required
@admin_required
def assign_task(request):
    if request.method == "POST":
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.assigned_by = request.user
            task.save()
            messages.success(request, "Task assigned successfully!")
            return redirect("admin_dashboard")
    else:
        form = TaskForm()
    return render(request, "employee/assign_task.html", {"form": form})


# ✅ Add performance review (Admin only)
@login_required
@admin_required
def add_review(request):
    if request.method == "POST":
        form = PerformanceReviewForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Performance review added successfully!")
            return redirect("admin_dashboard")
    else:
        form = PerformanceReviewForm()
    return render(request, "employee/add_review.html", {"form": form})

# ✅ Employee: View Tasks
@login_required
@employee_required
def view_tasks(request):
    tasks = Task.objects.filter(assigned_to=request.user)
    return render(request, "employee/view_tasks.html", {"tasks": tasks})

# ✅ Employee: View Attendance Logs
@login_required
@employee_required
def view_attendance(request):
    attendance_records = Attendance.objects.filter(user=request.user).order_by('-login_time')

    # Calculate attendance percentage (example: days logged in / total days)
    total_days = attendance_records.count()
    present_days = attendance_records.exclude(logout_time=None).count()
    attendance_percentage = (present_days / total_days * 100) if total_days > 0 else 0

    return render(request, "employee/view_attendance.html", {
        "attendance_records": attendance_records,
        "attendance_percentage": attendance_percentage,
    })

# ✅ Employee: View Salary Details
@login_required
@employee_required
def view_salary(request):
    salary_details = Salary.objects.filter(user=request.user)
    return render(request, "employee/view_salary.html", {"salary_details": salary_details})

# ✅ Employee: View Progress Chart
@login_required
@employee_required
def view_progress(request):
    # Example: tasks completed vs pending
    completed = Task.objects.filter(assigned_to=request.user, status="Completed").count()
    pending = Task.objects.filter(assigned_to=request.user, status="Pending").count()

    return render(request, "employee/view_progress.html", {
        "completed": completed,
        "pending": pending,
    })

@login_required
def assigned_tasks(request):
    # Show all tasks assigned by Admin
    tasks = Task.objects.all().order_by('-due_date')
    return render(request, "employee/assigned_tasks.html", {"tasks": tasks})

